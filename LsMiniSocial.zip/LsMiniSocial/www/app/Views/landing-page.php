<!DOCTYPE html>
<html lang="<?= service('request')->getLocale() ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= lang('App.app_name') ?> — <?= lang('App.landing_title') ?></title>
    <link rel="stylesheet" href="<?= base_url('css/landing.css') ?>">
</head>
<body>

<!-- NAV -->
<nav>
    <a href="<?= route_to('landing') ?>" class="nav-logo"><?= lang('App.app_name') ?></a>
    <div class="nav-links">
        <a href="<?= route_to('login') ?>" class="btn btn-ghost"><?= lang('App.sign_in') ?></a>
        <a href="<?= route_to('register') ?>" class="btn btn-primary"><?= lang('App.get_started') ?></a>
    </div>
</nav>

<!-- HERO -->
<section class="hero">
    <div class="hero-badge">
        <svg width="14" height="14" viewBox="0 0 24 24" fill="currentColor"><path d="M12 3L13.9 8.6H20L15.1 12L17 17.6L12 14.2L7 17.6L8.9 12L4 8.6H10.1L12 3Z"/></svg>
        <?= lang('App.community_platform') ?>
    </div>
    <h1><?= lang('App.hero_title') ?><br><span><?= lang('App.hero_span') ?></span></h1>
    <p><?= lang('App.hero_text') ?></p>
    <div class="hero-cta">
        <a href="<?= route_to('register') ?>" class="btn btn-primary btn-large"><?= lang('App.create_free_account') ?></a>
        <a href="<?= route_to('login') ?>" class="btn btn-ghost btn-large"><?= lang('App.sign_in') ?></a>
    </div>

    <!-- Floating post cards in hero -->
    <div class="hero-float-cards" aria-hidden="true">
        <div class="float-card float-card-1">
            <img src="https://picsum.photos/seed/lss1/48/48" alt="">
            <div class="float-card-body">
                <span class="float-name">marta.gil</span>
                <span class="float-text"><?= lang('App.float_text_1') ?></span>
            </div>
            <div class="float-likes">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="#f472b6"><path d="M12 21.593c-5.63-5.539-11-10.297-11-14.402 0-3.791 3.068-5.191 5.281-5.191 1.312 0 4.151.501 5.719 4.457 1.59-3.968 4.464-4.447 5.726-4.447 2.54 0 5.274 1.621 5.274 5.181 0 4.069-5.136 8.625-11 14.402z"/></svg>
                24
            </div>
        </div>
        <div class="float-card float-card-2">
            <img src="https://picsum.photos/seed/lss2/48/48" alt="">
            <div class="float-card-body">
                <span class="float-name">jordi.mas</span>
                <span class="float-text"><?= lang('App.float_text_2') ?></span>
            </div>
            <div class="float-likes">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="#f472b6"><path d="M12 21.593c-5.63-5.539-11-10.297-11-14.402 0-3.791 3.068-5.191 5.281-5.191 1.312 0 4.151.501 5.719 4.457 1.59-3.968 4.464-4.447 5.726-4.447 2.54 0 5.274 1.621 5.274 5.181 0 4.069-5.136 8.625-11 14.402z"/></svg>
                41
            </div>
        </div>
        <div class="float-card float-card-3">
            <img src="https://picsum.photos/seed/lss3/48/48" alt="">
            <div class="float-card-body">
                <span class="float-name">sofia.rc</span>
                <span class="float-text"><?= lang('App.float_text_3') ?></span>
            </div>
            <div class="float-likes">
                <svg width="12" height="12" viewBox="0 0 24 24" fill="#f472b6"><path d="M12 21.593c-5.63-5.539-11-10.297-11-14.402 0-3.791 3.068-5.191 5.281-5.191 1.312 0 4.151.501 5.719 4.457 1.59-3.968 4.464-4.447 5.726-4.447 2.54 0 5.274 1.621 5.274 5.181 0 4.069-5.136 8.625-11 14.402z"/></svg>
                18
            </div>
        </div>
    </div>
</section>

<!-- STATS -->
<div class="stats" data-animate="fade-up">
    <div class="stat">
        <div class="stat-number">@salle.url.edu</div>
        <div class="stat-label"><?= lang('App.exclusive_domain_access') ?></div>
    </div>
    <div class="stat">
        <div class="stat-number">
            <svg width="28" height="28" viewBox="0 0 24 24" fill="url(#grad1)" style="vertical-align:middle">
                <defs><linearGradient id="grad1" x1="0%" y1="0%" x2="100%" y2="100%"><stop offset="0%" style="stop-color:#1a73e8"/><stop offset="100%" style="stop-color:#5c35d4"/></linearGradient></defs>
                <path d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4L12 17l-6.2 4.3 2.4-7.4L2 9.4h7.6L12 2z"/>
            </svg>
            AI
        </div>
        <div class="stat-label"><?= lang('App.powered_text_enhancement') ?></div>
    </div>
    <div class="stat">
        <div class="stat-number">100%</div>
        <div class="stat-label"><?= lang('App.la_salle_community') ?></div>
    </div>
</div>

<!-- COMMUNITY POSTS SHOWCASE -->
<section class="community" data-animate="fade-up">
    <p class="section-label"><?= lang('App.real_moments') ?></p>
    <h2 class="section-title"><?= lang('App.community_title') ?></h2>
    <p class="section-sub"><?= lang('App.community_text') ?></p>

    <div class="posts-grid">
        <div class="post-card" data-animate="fade-up" data-delay="0">
            <div class="post-img-wrap">
                <img src="https://picsum.photos/seed/outdoor1/600/400" alt="<?= lang('App.student_outdoors') ?>">
                <div class="post-overlay">
                    <div class="post-likes-overlay">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="#fff"><path d="M12 21.593c-5.63-5.539-11-10.297-11-14.402 0-3.791 3.068-5.191 5.281-5.191 1.312 0 4.151.501 5.719 4.457 1.59-3.968 4.464-4.447 5.726-4.447 2.54 0 5.274 1.621 5.274 5.181 0 4.069-5.136 8.625-11 14.402z"/></svg>
                        47
                    </div>
                </div>
            </div>
            <div class="post-meta">
                <img src="https://picsum.photos/seed/lss1/40/40" alt="" class="post-avatar">
                <div>
                    <div class="post-author">marta.gil</div>
                    <div class="post-caption"><?= lang('App.post_caption_1') ?></div>
                </div>
            </div>
        </div>

        <div class="post-card" data-animate="fade-up" data-delay="100">
            <div class="post-img-wrap">
                <img src="https://picsum.photos/seed/selfie2/600/400" alt="<?= lang('App.student_selfie') ?>">
                <div class="post-overlay">
                    <div class="post-likes-overlay">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="#fff"><path d="M12 21.593c-5.63-5.539-11-10.297-11-14.402 0-3.791 3.068-5.191 5.281-5.191 1.312 0 4.151.501 5.719 4.457 1.59-3.968 4.464-4.447 5.726-4.447 2.54 0 5.274 1.621 5.274 5.181 0 4.069-5.136 8.625-11 14.402z"/></svg>
                        62
                    </div>
                </div>
            </div>
            <div class="post-meta">
                <img src="https://picsum.photos/seed/lss4/40/40" alt="" class="post-avatar">
                <div>
                    <div class="post-author">pau.vidal</div>
                    <div class="post-caption"><?= lang('App.post_caption_2') ?></div>
                </div>
            </div>
        </div>

        <div class="post-card" data-animate="fade-up" data-delay="200">
            <div class="post-img-wrap">
                <img src="https://picsum.photos/seed/nature3/600/400" alt="<?= lang('App.nature_photo') ?>">
                <div class="post-overlay">
                    <div class="post-likes-overlay">
                        <svg width="18" height="18" viewBox="0 0 24 24" fill="#fff"><path d="M12 21.593c-5.63-5.539-11-10.297-11-14.402 0-3.791 3.068-5.191 5.281-5.191 1.312 0 4.151.501 5.719 4.457 1.59-3.968 4.464-4.447 5.726-4.447 2.54 0 5.274 1.621 5.274 5.181 0 4.069-5.136 8.625-11 14.402z"/></svg>
                        35
                    </div>
                </div>
            </div>
            <div class="post-meta">
                <img src="https://picsum.photos/seed/lss3/40/40" alt="" class="post-avatar">
                <div>
                    <div class="post-author">sofia.rc</div>
                    <div class="post-caption"><?= lang('App.post_caption_3') ?></div>
                </div>
            </div>
        </div>
    </div>
</section>

<!-- FEATURES -->
<section class="features" data-animate="fade-up">
    <p class="section-label"><?= lang('App.features') ?></p>
    <h2 class="section-title"><?= lang('App.features_title') ?></h2>
    <p class="section-sub"><?= lang('App.features_text') ?></p>

    <div class="features-grid">
        <div class="feature-card" data-animate="fade-up" data-delay="0">
            <div class="feature-icon icon-blue">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#60a5fa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/><polyline points="21 15 16 10 5 21"/></svg>
            </div>
            <h3><?= lang('App.feature_posts_title') ?></h3>
            <p><?= lang('App.feature_posts_text') ?></p>
        </div>

        <div class="feature-card" data-animate="fade-up" data-delay="80">
            <div class="feature-icon icon-pink">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="#f472b6"><path d="M12 21.593c-5.63-5.539-11-10.297-11-14.402 0-3.791 3.068-5.191 5.281-5.191 1.312 0 4.151.501 5.719 4.457 1.59-3.968 4.464-4.447 5.726-4.447 2.54 0 5.274 1.621 5.274 5.181 0 4.069-5.136 8.625-11 14.402z"/></svg>
            </div>
            <h3><?= lang('App.feature_likes_title') ?></h3>
            <p><?= lang('App.feature_likes_text') ?></p>
        </div>

        <div class="feature-card" data-animate="fade-up" data-delay="160">
            <div class="feature-icon icon-green">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#34d399" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/></svg>
            </div>
            <h3><?= lang('App.comments') ?></h3>
            <p><?= lang('App.feature_comments_text') ?></p>
        </div>

        <div class="feature-card" data-animate="fade-up" data-delay="0">
            <div class="feature-icon icon-purple">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#a78bfa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4L12 17l-6.2 4.3 2.4-7.4L2 9.4h7.6L12 2z"/></svg>
            </div>
            <h3><?= lang('App.feature_ai_title') ?></h3>
            <p><?= lang('App.feature_ai_text') ?></p>
        </div>

        <div class="feature-card" data-animate="fade-up" data-delay="80">
            <div class="feature-icon icon-amber">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#fbbf24" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/></svg>
            </div>
            <h3><?= lang('App.feature_profile_title') ?></h3>
            <p><?= lang('App.feature_profile_text') ?></p>
        </div>

        <div class="feature-card" data-animate="fade-up" data-delay="160">
            <div class="feature-icon icon-red">
                <svg width="24" height="24" viewBox="0 0 24 24" fill="none" stroke="#f87171" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><rect x="3" y="11" width="18" height="11" rx="2" ry="2"/><path d="M7 11V7a5 5 0 0 1 10 0v4"/></svg>
            </div>
            <h3><?= lang('App.feature_access_title') ?></h3>
            <p><?= lang('App.feature_access_text') ?></p>
        </div>
    </div>
</section>

<!-- AI SPOTLIGHT -->
<section class="ai-section">
    <div class="ai-inner">
        <div class="ai-text" data-animate="fade-right">
            <p class="section-label" style="text-align:left;"><?= lang('App.ai_writing') ?></p>
            <h2><?= lang('App.ai_title') ?><br><span><?= lang('App.ai_span') ?></span></h2>
            <p><?= lang('App.ai_text') ?></p>
            <a href="<?= route_to('register') ?>" class="btn btn-primary"><?= lang('App.try_free') ?></a>
        </div>
        <div class="ai-demo" data-animate="fade-left">
            <div class="demo-label"><?= lang('App.before') ?></div>
            <div class="demo-box"><?= lang('App.demo_before') ?></div>
            <div class="demo-arrow">
                <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="#60a5fa" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"><line x1="12" y1="5" x2="12" y2="19"/><polyline points="19 12 12 19 5 12"/></svg>
                <?= lang('App.ai_enhancement') ?>
            </div>
            <div class="demo-label"><?= lang('App.after') ?></div>
            <div class="demo-box improved"><?= lang('App.demo_after') ?></div>
        </div>
    </div>
</section>

<!-- CTA -->
<section class="cta-section" data-animate="fade-up">
    <h2><?= lang('App.cta_title') ?></h2>
    <p><?= lang('App.cta_text') ?></p>
    <a href="<?= route_to('register') ?>" class="btn btn-primary btn-large"><?= lang('App.create_account') ?> &rarr;</a>
</section>

<!-- FOOTER -->
<footer>
    &copy; <?= date('Y') ?> <?= lang('App.app_name') ?> &mdash; La Salle Campus Barcelona
</footer>

<script src="<?= base_url('assets/js/landing.js') ?>"></script>

</body>
</html>