<?= $this->extend('layout/auth') ?>

<?= $this->section('title') ?><?= lang('App.sign_up') ?><?= $this->endSection() ?>

<?= $this->section('left') ?>
    <a href="<?= route_to('landing') ?>" class="auth-brand">LsMiniSocial</a>

    <h1 class="auth-left-title">
        <?= lang('App.register_title_line1') ?><br>
        <span><?= lang('App.register_title_line2') ?></span>
    </h1>
    <p class="auth-left-sub">
        <?= lang('App.register_left_sub') ?>
    </p>

    <ul class="auth-perks">
        <li class="auth-perk">
            <div class="perk-icon perk-icon-blue">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#60a5fa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                    <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                </svg>
            </div>
            <div class="perk-text">
                <strong><?= lang('App.register_perk_access_title') ?></strong>
                <?= lang('App.register_perk_access_text') ?>
            </div>
        </li>
        <li class="auth-perk">
            <div class="perk-icon perk-icon-pink">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="#f472b6">
                    <path d="M12 21.593c-5.63-5.539-11-10.297-11-14.402 0-3.791 3.068-5.191 5.281-5.191 1.312 0 4.151.501 5.719 4.457 1.59-3.968 4.464-4.447 5.726-4.447 2.54 0 5.274 1.621 5.274 5.181 0 4.069-5.136 8.625-11 14.402z"/>
                </svg>
            </div>
            <div class="perk-text">
                <strong><?= lang('App.register_perk_likes_title') ?></strong>
                <?= lang('App.register_perk_likes_text') ?>
            </div>
        </li>
        <li class="auth-perk">
            <div class="perk-icon perk-icon-purple">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#a78bfa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M12 2l2.4 7.4H22l-6.2 4.5 2.4 7.4L12 17l-6.2 4.3 2.4-7.4L2 9.4h7.6L12 2z"/>
                </svg>
            </div>
            <div class="perk-text">
                <strong><?= lang('App.register_perk_ai_title') ?></strong>
                <?= lang('App.register_perk_ai_text') ?>
            </div>
        </li>
        <li class="auth-perk">
            <div class="perk-icon perk-icon-green">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#34d399" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                </svg>
            </div>
            <div class="perk-text">
                <strong><?= lang('App.register_perk_comments_title') ?></strong>
                <?= lang('App.register_perk_comments_text') ?>
            </div>
        </li>
    </ul>

    <div class="auth-testimonial">
        <p class="auth-testimonial-text">
            <?= lang('App.register_testimonial_text') ?>
        </p>
        <div class="auth-testimonial-author">
            <img src="https://picsum.photos/seed/lss5/64/64" alt="Student">
            <div>
                <div class="auth-testimonial-name">marta.gil</div>
                <div class="auth-testimonial-role"><?= lang('App.register_testimonial_role') ?></div>
            </div>
        </div>
    </div>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
    <div class="auth-card-header">
        <a href="<?= route_to('landing') ?>" class="auth-brand" style="display:block;margin-bottom:1.5rem;">LsMiniSocial</a>

        <div class="auth-step-badge">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="currentColor">
                <path d="M12 3L13.9 8.6H20L15.1 12L17 17.6L12 14.2L7 17.6L8.9 12L4 8.6H10.1L12 3Z"/>
            </svg>
            <?= lang('App.step') ?> 1 <?= lang('App.of') ?> 1
        </div>

        <h1 class="auth-card-title"><?= lang('App.register_card_title') ?></h1>
        <p class="auth-card-sub"><?= lang('App.register_card_sub') ?></p>
    </div>

<?php if (session('errors') && is_array(session('errors'))): ?>
    <div class="alert-error" role="alert">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0">
            <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
        </svg>
        <div>
            <strong><?= lang('App.fix_errors') ?></strong>
            <ul style="margin-top:.3rem;padding-left:1rem;">
                <?php foreach (session('errors') as $error): ?>
                    <li><?= esc($error) ?></li>
                <?php endforeach; ?>
            </ul>
        </div>
    </div>
<?php endif; ?>

    <form method="post" action="<?= route_to('register.store') ?>" enctype="multipart/form-data">
        <?= csrf_field() ?>

        <div class="form-group">
            <label class="form-label" for="username"><?= lang('App.username') ?> <span style="opacity:.5;font-weight:400">(optional)</span></label>
            <div class="input-wrap">
            <span class="input-icon">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
                    <circle cx="12" cy="7" r="4"/>
                </svg>
            </span>
                <input type="text" id="username" name="username" class="form-input"
                       placeholder="<?= lang('App.username_placeholder') ?>"
                       value="<?= old('username') ?>" autocomplete="username" spellcheck="false">
            </div>
        </div>

        <div class="form-group">
            <label class="form-label" for="profile_picture"><?= lang('App.image') ?> <span style="opacity:.5;font-weight:400">(optional)</span></label>
            <div class="input-wrap">
            <span class="input-icon">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="3" width="18" height="18" rx="2" ry="2"/>
                    <circle cx="8.5" cy="8.5" r="1.5"/>
                    <polyline points="21 15 16 10 5 21"/>
                </svg>
            </span>
                <input type="file" id="profile_picture" name="profile_picture"
                       class="form-input <?= session('errors.profile_picture') ? 'is-error' : '' ?>" accept="image/*">
            </div>
        </div>

        <div class="form-group">
            <label class="form-label" for="email"><?= lang('App.email_address') ?></label>
            <div class="input-wrap">
            <span class="input-icon">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                    <polyline points="22,6 12,13 2,6"/>
                </svg>
            </span>
                <input type="email" id="email" name="email"
                       class="form-input <?= session('errors.email') ? 'is-error' : '' ?>"
                       placeholder="you@salle.url.edu" value="<?= old('email') ?>"
                       autocomplete="email" spellcheck="false">
            </div>
        </div>

        <div class="form-group">
            <label class="form-label" for="password"><?= lang('App.password') ?></label>
            <div class="input-wrap">
            <span class="input-icon">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                    <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                </svg>
            </span>
                <input type="password" id="password" name="password"
                       class="form-input <?= session('errors.password') ? 'is-error' : '' ?>"
                       placeholder="<?= lang('App.password_placeholder') ?>" autocomplete="new-password">
            </div>
        </div>

        <div class="form-group">
            <label class="form-label" for="password_repeat"><?= lang('App.repeat_password') ?></label>
            <div class="input-wrap">
            <span class="input-icon">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
                </svg>
            </span>
                <input type="password" id="password_repeat" name="password_repeat"
                       class="form-input <?= session('errors.password_repeat') ? 'is-error' : '' ?>"
                       placeholder="<?= lang('App.repeat_password_placeholder') ?>" autocomplete="new-password">
            </div>
        </div>

        <button type="submit" class="btn-submit">
            <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M16 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
                <circle cx="8.5" cy="7" r="4"/>
                <line x1="20" y1="8" x2="20" y2="14"/>
                <line x1="23" y1="11" x2="17" y2="11"/>
            </svg>
            <?= lang('App.sign_up') ?>
        </button>
    </form>

    <p class="auth-footer">
        <?= lang('App.already_account') ?>
        <a href="<?= route_to('login') ?>"><?= lang('App.sign_in') ?> &rarr;</a>
    </p>

    <p class="auth-terms">
        <?= lang('App.terms') ?><br>
        <?= lang('App.only_salle') ?>
    </p>
<?= $this->endSection() ?>