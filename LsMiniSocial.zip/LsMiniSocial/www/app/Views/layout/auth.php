<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $this->renderSection('title') ?> — LsMiniSocial</title>
    <link rel="stylesheet" href="<?= base_url('css/auth.css') ?>">
</head>
<body>

<div class="auth-bg">
    <div class="auth-bg-blob3"></div>
</div>

<div class="auth-wrap">
    <aside class="auth-left">
        <?= $this->renderSection('left') ?>
    </aside>

    <main class="auth-right">
        <div class="auth-card">
            <?= $this->renderSection('content') ?>
        </div>
    </main>
</div>

</body>
</html>
