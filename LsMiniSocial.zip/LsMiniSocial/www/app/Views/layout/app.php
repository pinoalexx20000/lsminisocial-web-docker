<!DOCTYPE html>
<html lang="<?= service('request')->getLocale() ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= $this->renderSection('title') ?> — <?= lang('App.app_name') ?></title>
    <link rel="stylesheet" href="<?= base_url('css/home.css') ?>">
    <?= $this->renderSection('head') ?>
</head>
<body>

<?php $currentPath = ltrim(service('uri')->getPath(), '/'); ?>

<nav class="navbar">
    <div class="navbar-inner">
        <a href="<?= route_to('home') ?>" class="nav-brand"><?= lang('App.app_name') ?></a>

        <div class="nav-links">
            <a href="<?= route_to('home') ?>" class="nav-link <?= $currentPath === 'home' ? 'active' : '' ?>">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/><polyline points="9 22 9 12 15 12 15 22"/>
                </svg>
                <?= lang('App.feed') ?>
            </a>

            <a href="<?= route_to('post.create') ?>" class="nav-link <?= str_starts_with($currentPath, 'post') ? 'active' : '' ?>">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <line x1="12" y1="5" x2="12" y2="19"/><line x1="5" y1="12" x2="19" y2="12"/>
                </svg>
                <?= lang('App.new_post') ?>
            </a>

            <a href="<?= route_to('profile') ?>" class="nav-link <?= $currentPath === 'profile' ? 'active' : '' ?>">
                <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/><circle cx="12" cy="7" r="4"/>
                </svg>
                <?= lang('App.profile') ?>
            </a>
        </div>

        <div class="nav-user">
            <img
                    src="<?= base_url(session('user_profile_picture') ?: 'uploads/profile_pictures/default.png') ?>"
                    class="nav-avatar"
                    alt="<?= esc(session('user_name')) ?>"
            >
            <span class="nav-username"><?= esc(session('user_name')) ?></span>

            <a href="<?= route_to('logout') ?>" class="nav-logout">
                <svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M9 21H5a2 2 0 0 1-2-2V5a2 2 0 0 1 2-2h4"/><polyline points="16 17 21 12 16 7"/><line x1="21" y1="12" x2="9" y2="12"/>
                </svg>
                <?= lang('App.logout') ?>
            </a>
        </div>
    </div>
</nav>

<main class="feed-wrap <?= $this->renderSection('mainClass') ?>">
    <?= $this->renderSection('content') ?>
</main>

<?= $this->renderSection('scripts') ?>

</body>
</html>