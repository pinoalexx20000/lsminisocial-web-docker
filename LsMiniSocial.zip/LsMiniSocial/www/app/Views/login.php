<?= $this->extend('layout/auth') ?>

<?= $this->section('title') ?><?= lang('App.sign_in') ?><?= $this->endSection() ?>

<?= $this->section('left') ?>
    <a href="<?= route_to('landing') ?>" class="auth-brand"><?= lang('App.app_name') ?></a>

    <h1 class="auth-left-title">
        <?= lang('App.login_welcome') ?><br>
        <span><?= lang('App.login_back') ?></span>
    </h1>
    <p class="auth-left-sub">
        <?= lang('App.login_left_sub') ?>
    </p>

    <ul class="auth-perks">
        <li class="auth-perk">
            <div class="perk-icon perk-icon-blue">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#60a5fa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M3 9l9-7 9 7v11a2 2 0 0 1-2 2H5a2 2 0 0 1-2-2z"/>
                    <polyline points="9 22 9 12 15 12 15 22"/>
                </svg>
            </div>
            <div class="perk-text">
                <strong><?= lang('App.login_perk_feed_title') ?></strong>
                <?= lang('App.login_perk_feed_text') ?>
            </div>
        </li>
        <li class="auth-perk">
            <div class="perk-icon perk-icon-pink">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="#f472b6">
                    <path d="M12 21.593c-5.63-5.539-11-10.297-11-14.402 0-3.791 3.068-5.191 5.281-5.191 1.312 0 4.151.501 5.719 4.457 1.59-3.968 4.464-4.447 5.726-4.447 2.54 0 5.274 1.621 5.274 5.181 0 4.069-5.136 8.625-11 14.402z"/>
                </svg>
            </div>
            <div class="perk-text">
                <strong><?= lang('App.login_perk_reactions_title') ?></strong>
                <?= lang('App.login_perk_reactions_text') ?>
            </div>
        </li>
        <li class="auth-perk">
            <div class="perk-icon perk-icon-purple">
                <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="#a78bfa" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                </svg>
            </div>
            <div class="perk-text">
                <strong><?= lang('App.login_perk_discussions_title') ?></strong>
                <?= lang('App.login_perk_discussions_text') ?>
            </div>
        </li>
    </ul>

    <div class="auth-testimonial">
        <p class="auth-testimonial-text">
            <?= lang('App.login_testimonial_text') ?>
        </p>
        <div class="auth-testimonial-author">
            <img src="https://picsum.photos/seed/lss2/64/64" alt="<?= lang('App.student') ?>">
            <div>
                <div class="auth-testimonial-name">jordi.mas</div>
                <div class="auth-testimonial-role"><?= lang('App.login_testimonial_role') ?></div>
            </div>
        </div>
    </div>
<?= $this->endSection() ?>

<?= $this->section('content') ?>
    <div class="auth-card-header">
        <a href="<?= route_to('landing') ?>" class="auth-brand" style="display:block;margin-bottom:1.5rem;"><?= lang('App.app_name') ?></a>

        <div class="auth-step-badge">
            <svg width="11" height="11" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/><polyline points="10 17 15 12 10 7"/><line x1="15" y1="12" x2="3" y2="12"/>
            </svg>
            <?= lang('App.sign_in') ?>
        </div>

        <h1 class="auth-card-title"><?= lang('App.login_card_title') ?></h1>
        <p class="auth-card-sub"><?= lang('App.login_card_sub') ?></p>
    </div>

<?php if (session('errors') && is_array(session('errors'))): ?>
    <div class="alert-error" role="alert">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0">
            <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
        </svg>
        <div>
            <?php foreach (session('errors') as $error): ?>
                <div><?= esc($error) ?></div>
            <?php endforeach; ?>
        </div>
    </div>
<?php endif; ?>

<?php if (session('error')): ?>
    <div class="alert-error" role="alert">
        <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="flex-shrink:0">
            <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
        </svg>
        <?= esc(session('error')) ?>
    </div>
<?php endif; ?>

    <form method="post" action="<?= route_to('login.store') ?>">
        <?= csrf_field() ?>

        <div class="form-group">
            <label class="form-label" for="email"><?= lang('App.email_address') ?></label>
            <div class="input-wrap">
            <span class="input-icon">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
                    <polyline points="22,6 12,13 2,6"/>
                </svg>
            </span>
                <input type="email" id="email" name="email"
                       class="form-input <?= session('errors.email') ? 'is-error' : '' ?>"
                       placeholder="<?= lang('App.email_placeholder') ?>" value="<?= old('email') ?>"
                       autocomplete="email" spellcheck="false">
            </div>
            <?php if (session('errors.email')): ?>
                <p class="field-error">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
                    </svg>
                    <?= esc(session('errors.email')) ?>
                </p>
            <?php endif; ?>
        </div>

        <div class="form-group">
            <label class="form-label" for="password"><?= lang('App.password') ?></label>
            <div class="input-wrap">
            <span class="input-icon">
                <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
                    <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
                </svg>
            </span>
                <input type="password" id="password" name="password"
                       class="form-input <?= session('errors.password') ? 'is-error' : '' ?>"
                       placeholder="<?= lang('App.your_password') ?>" autocomplete="current-password">
            </div>
            <?php if (session('errors.password')): ?>
                <p class="field-error">
                    <svg width="13" height="13" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round">
                        <circle cx="12" cy="12" r="10"/><line x1="12" y1="8" x2="12" y2="12"/><line x1="12" y1="16" x2="12.01" y2="16"/>
                    </svg>
                    <?= esc(session('errors.password')) ?>
                </p>
            <?php endif; ?>
        </div>

        <button type="submit" class="btn-submit">
            <svg width="17" height="17" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                <path d="M15 3h4a2 2 0 0 1 2 2v14a2 2 0 0 1-2 2h-4"/>
                <polyline points="10 17 15 12 10 7"/>
                <line x1="15" y1="12" x2="3" y2="12"/>
            </svg>
            <?= lang('App.sign_in') ?>
        </button>
    </form>

    <p class="auth-footer">
        <?= lang('App.no_account') ?>
        <a href="<?= route_to('register') ?>"><?= lang('App.create_one_here') ?> &rarr;</a>
    </p>
<?= $this->endSection() ?>