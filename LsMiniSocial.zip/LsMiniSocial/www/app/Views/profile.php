<?= $this->extend('layout/app') ?>

<?= $this->section('title') ?><?= lang('App.profile') ?><?= $this->endSection() ?>

<?= $this->section('head') ?>
    <meta name="csrf-token-name"  content="<?= csrf_token() ?>">
    <meta name="csrf-token-value" content="<?= csrf_hash() ?>">
    <meta name="current-user-id"  content="<?= session('user_id') ?>">
    <meta name="base-url"         content="<?= base_url() ?>">
<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
    <script src="<?= base_url('assets/js/ajax.js') ?>"></script>
<?= $this->endSection() ?>

<?= $this->section('mainClass') ?>profile-page<?= $this->endSection() ?>

<?= $this->section('content') ?>

<?php if (session('errors')): ?>
    <div class="alert-error">
        <?php foreach ((array) session('errors') as $err): ?>
            <div><?= esc($err) ?></div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php if (session('error')): ?>
    <div class="alert-error">
        <div><?= esc(session('error')) ?></div>
    </div>
<?php endif; ?>

<?php if (session('success')): ?>
    <div class="alert-success">
        <div><?= esc(session('success')) ?></div>
    </div>
<?php endif; ?>

    <section class="card profile-card">
        <div class="profile-top">
            <img
                    src="<?= base_url(($user['profile_pic'] ?? session('user_profile_picture')) ?: 'uploads/profile_pictures/default.png') ?>"
                    class="profile-avatar-large"
                    alt="<?= esc($user['username'] ?? session('user_name')) ?>"
            >
            <div class="profile-main-info">
                <h1><?= esc($user['username'] ?? session('user_name')) ?></h1>
                <p><?= esc($user['email'] ?? session('user_email')) ?></p>
            </div>
        </div>

        <form method="post" action="<?= route_to('profile.update') ?>" enctype="multipart/form-data" class="profile-form">
            <?= csrf_field() ?>

            <div class="profile-form-group">
                <label for="username"><?= lang('App.username') ?></label>
                <input type="text" id="username" name="username" value="<?= esc($user['username'] ?? session('user_name')) ?>">
            </div>

            <div class="profile-form-group">
                <label for="email"><?= lang('App.email') ?></label>
                <input type="email" id="email" value="<?= esc($user['email'] ?? session('user_email')) ?>" readonly>
            </div>

            <div class="profile-form-group">
                <label for="password"><?= lang('App.new_password') ?></label>
                <input type="password" id="password" name="password" placeholder="<?= lang('App.write_new_password') ?>">
            </div>

            <div class="profile-form-group">
                <label for="profile_picture"><?= lang('App.profile_picture') ?></label>
                <input type="file" id="profile_picture" name="profile_picture" accept="image/*">
            </div>

            <div class="profile-actions">
                <button type="submit" class="btn-post"><?= lang('App.save_changes') ?></button>
                <a href="<?= route_to('logout') ?>" class="btn-edit-link"><?= lang('App.logout') ?></a>
            </div>
        </form>

        <form method="post" action="<?= route_to('profile.delete') ?>" onsubmit="return confirm('<?= lang('App.delete_account_confirm') ?>');">
            <?= csrf_field() ?>
            <button type="submit" class="btn-delete-post"><?= lang('App.delete_account') ?></button>
        </form>
    </section>

    <section class="card">
        <div class="section-title"><?= lang('App.your_posts') ?></div>

        <?php if (empty($posts)): ?>
            <div class="empty-posts"><?= lang('App.no_profile_posts') ?></div>
        <?php else: ?>
            <div class="profile-post-list">
                <?php foreach ($posts as $post): ?>
                    <article class="profile-post-item">
                        <div class="profile-post-content"><?= nl2br(esc($post['content'])) ?></div>

                        <?php if (!empty($post['image'])): ?>
                            <img src="<?= base_url($post['image']) ?>" class="profile-post-image" alt="<?= lang('App.post_image') ?>">
                        <?php endif; ?>

                        <div class="owner-post-actions">
                            <a href="<?= route_to('post.edit', $post['id']) ?>" class="btn-edit-link"><?= lang('App.edit') ?></a>
                            <button type="button" class="btn-delete-post" data-post-id="<?= $post['id'] ?>"><?= lang('App.delete') ?></button>
                        </div>

                        <div class="profile-post-date">
                            <?= date('M j, Y · g:i a', strtotime($post['created_at'])) ?>
                        </div>
                    </article>
                <?php endforeach; ?>
            </div>
        <?php endif; ?>
    </section>

<?= $this->endSection() ?>