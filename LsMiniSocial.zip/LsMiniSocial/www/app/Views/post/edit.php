<?= $this->extend('layout/app') ?>

<?= $this->section('title') ?>Edit Post<?= $this->endSection() ?>

<?= $this->section('head') ?>
<meta name="csrf-token-name" content="<?= csrf_token() ?>">
<meta name="csrf-token-value" content="<?= csrf_hash() ?>">
<?= $this->endSection() ?>

<?= $this->section('content') ?>

    <div class="card">
        <div class="create-post-header">
            <img
                    src="<?= base_url(session('user_profile_picture') ?: 'uploads/profile_pictures/default.png') ?>"
                    class="create-post-avatar"
                    alt="You"
            >
            <span>Edit your post</span>
        </div>

        <div id="edit-error-box" class="alert-error" style="display:none;"></div>

        <form
                id="edit-post-form"
                enctype="multipart/form-data"
                data-update-url="<?= route_to('posts.update', $post['id']) ?>"
                data-home-url="<?= route_to('home') ?>"
        >
            <?= csrf_field() ?>

            <textarea
                    name="content"
                    id="edit-content"
                    class="post-textarea"
                    placeholder="Update your post..."
                    maxlength="1000"
            ><?= esc($post['content']) ?></textarea>

            <?php if (!empty($post['image'])): ?>
                <img src="<?= base_url($post['image']) ?>" class="post-image" alt="Post image">
            <?php endif; ?>

            <div class="create-post-actions">
                <label class="btn-attach" id="edit-attach-label">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/>
                        <polyline points="21 15 16 10 5 21"/>
                    </svg>
                    Change photo
                    <span class="file-label-name" id="edit-file-name-display"></span>
                    <input type="file" name="image" accept="image/*" hidden id="edit-post-image-input">
                </label>

                <div class="edit-form-actions">
                    <a href="<?= route_to('home') ?>" class="btn-edit-link">Cancel</a>
                    <button type="submit" class="btn-post">Save</button>
                </div>
            </div>
        </form>
    </div>

<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script src="<?= base_url('assets/js/edit-post.js') ?>"></script>
<?= $this->endSection() ?>
