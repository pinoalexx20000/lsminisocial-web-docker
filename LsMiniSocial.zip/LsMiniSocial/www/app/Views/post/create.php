<?= $this->extend('layout/app') ?>

<?= $this->section('title') ?>New Post<?= $this->endSection() ?>

<?= $this->section('head') ?>
<meta name="csrf-token-name"  content="<?= csrf_token() ?>">
<meta name="csrf-token-value" content="<?= csrf_hash() ?>">
<?= $this->endSection() ?>

<?= $this->section('content') ?>

    <div class="card">
        <div class="create-post-header">
            <img
                    src="<?= base_url(session('user_profile_picture') ?: 'uploads/profile_pictures/default.png') ?>"
                    class="create-post-avatar"
                    alt="You"
            >
            <span>What's on your mind, <?= esc(session('user_name')) ?>?</span>
        </div>

        <form method="post" action="<?= route_to('posts.store') ?>" enctype="multipart/form-data" id="create-post-form">
            <?= csrf_field() ?>
            <textarea
                    name="content"
                    id="post-content"
                    class="post-textarea"
                    placeholder="Share something with the La Salle community..."
                    maxlength="1000"
            ></textarea>

            <div id="ai-suggestion" style="display:none;" class="ai-suggestion-box">
                <p class="ai-suggestion-label">AI suggestion:</p>
                <p id="ai-suggestion-text" class="ai-suggestion-text"></p>
                <div class="ai-suggestion-actions">
                    <button type="button" id="btn-ai-accept" class="btn-post">Accept</button>
                    <button type="button" id="btn-ai-reject" class="btn-edit-link">Discard</button>
                </div>
            </div>

            <div class="create-post-actions">
                <label class="btn-attach" id="attach-label">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/>
                        <polyline points="21 15 16 10 5 21"/>
                    </svg>
                    Add photo
                    <span class="file-label-name" id="file-name-display"></span>
                    <input type="file" name="image" accept="image/*" hidden id="post-image-input">
                </label>
                <div class="edit-form-actions">
                    <button type="button" id="btn-ai-improve" class="btn-edit-link" title="Improve with AI" data-improve-url="<?= route_to('ai.improve') ?>">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:4px">
                            <path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/>
                        </svg>
                        Improve with AI
                    </button>
                    <a href="<?= route_to('home') ?>" class="btn-edit-link">Cancel</a>
                    <button type="submit" class="btn-post">
                        <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:4px">
                            <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
                        </svg>
                        Post
                    </button>
                </div>
            </div>
        </form>
    </div>

<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
<script src="<?= base_url('assets/js/create-post.js') ?>"></script>
<?= $this->endSection() ?>
