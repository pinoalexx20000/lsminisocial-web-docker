<?= $this->extend('layout/app') ?>

<?= $this->section('title') ?><?= lang('App.home') ?><?= $this->endSection() ?>

<?= $this->section('head') ?>
    <meta name="csrf-token-name" content="<?= csrf_token() ?>">
    <meta name="csrf-token-value" content="<?= csrf_hash() ?>">
    <meta name="current-user-id" content="<?= session('user_id') ?>">
    <meta name="base-url" content="<?= base_url() ?>">

<?= $this->endSection() ?>

<?= $this->section('content') ?>

<?php if (session('errors')): ?>
    <div class="alert-error">
        <?php foreach ((array) session('errors') as $err): ?>
            <div><?= esc($err) ?></div>
        <?php endforeach; ?>
    </div>
<?php endif; ?>

<?php if (session('error')): ?>
    <div class="alert-error">
        <div><?= esc(session('error')) ?></div>
    </div>
<?php endif; ?>

    <div class="card" id="create-post">
        <div class="create-post-header">
            <img src="<?= base_url(session('user_profile_picture') ?: 'uploads/profile_pictures/default.png') ?>" class="create-post-avatar" alt="<?= lang('App.you') ?>">
            <span><?= lang('App.whats_on_your_mind') ?>, <?= esc(session('user_name')) ?>?</span>
        </div>

        <form method="post" action="<?= route_to('posts.store') ?>" enctype="multipart/form-data">
            <?= csrf_field() ?>
            <textarea
                    name="content"
                    class="post-textarea"
                    placeholder="<?= lang('App.share_placeholder') ?>"
                    maxlength="1000"
            ></textarea>
            <div class="create-post-actions">
                <label class="btn-attach" id="attach-label">
                    <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <rect x="3" y="3" width="18" height="18" rx="2"/><circle cx="8.5" cy="8.5" r="1.5"/>
                        <polyline points="21 15 16 10 5 21"/>
                    </svg>
                    <?= lang('App.add_photo') ?>
                    <span class="file-label-name" id="file-name-display"></span>
                    <input type="file" name="image" accept="image/*" hidden id="post-image-input">
                </label>
                <button type="submit" class="btn-post">
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2.2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:4px">
                        <line x1="22" y1="2" x2="11" y2="13"/><polygon points="22 2 15 22 11 13 2 9 22 2"/>
                    </svg>
                    <?= lang('App.post') ?>
                </button>
            </div>
        </form>
    </div>

<?php if (empty($posts)): ?>
    <div class="empty-feed">
        <svg width="40" height="40" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="1.5" stroke-linecap="round" stroke-linejoin="round" style="margin-bottom:.75rem;opacity:.4">
            <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
        </svg>
        <p><?= lang('App.no_posts_yet') ?></p>
    </div>
<?php else: ?>
    <?php foreach ($posts as $post): ?>
        <article class="card" data-post-id="<?= $post['id'] ?>">

            <div class="post-author">
                <img
                        src="<?= base_url($post['profile_picture'] ?: 'uploads/profile_pictures/default.png') ?>"
                        class="post-avatar"
                        alt="<?= esc($post['username']) ?>"
                >
                <div>
                    <div class="post-username"><?= esc($post['username']) ?></div>
                    <div class="post-date"><?= date('M j, Y · g:i a', strtotime($post['created_at'])) ?></div>
                </div>
            </div>

            <p class="post-content"><?= nl2br(esc($post['content'])) ?></p>

            <?php if ($post['image']): ?>
                <img src="<?= base_url($post['image']) ?>" class="post-image" alt="<?= lang('App.post_image') ?>">
            <?php endif; ?>

            <?php if ($post['user_id'] == session('user_id')): ?>
                <div class="owner-post-actions">
                    <a href="<?= route_to('post.edit', $post['id']) ?>" class="btn-edit-link"><?= lang('App.edit') ?></a>
                    <button type="button" class="btn-delete-post" data-post-id="<?= $post['id'] ?>"><?= lang('App.delete') ?></button>
                </div>
            <?php endif; ?>

            <div class="post-actions">
                <button
                        class="btn-like <?= $post['user_liked'] ? 'liked' : '' ?>"
                        data-post-id="<?= $post['id'] ?>"
                        type="button"
                >
                    <svg class="like-heart" width="16" height="16" viewBox="0 0 24 24" fill="<?= $post['user_liked'] ? 'currentColor' : 'none' ?>" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 0 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z"/>
                    </svg>
                    <span class="like-count"><?= $post['likes_count'] ?></span>
                </button>

                <button
                        class="btn-comment-toggle"
                        data-post-id="<?= $post['id'] ?>"
                        type="button"
                >
                    <svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round">
                        <path d="M21 15a2 2 0 0 1-2 2H7l-4 4V5a2 2 0 0 1 2-2h14a2 2 0 0 1 2 2z"/>
                    </svg>
                    <span class="comment-count-text">
                            <?= $post['comments_count'] ?>
                            <?= $post['comments_count'] === 1 ? lang('App.comment') : lang('App.comments') ?>
                        </span>
                </button>
            </div>

            <div class="comments-section" id="comments-<?= $post['id'] ?>" style="display:none">

                <?php foreach ($post['comments'] as $comment): ?>
                    <div class="comment" data-comment-id="<?= $comment['id'] ?>" data-owner-id="<?= $comment['user_id'] ?>">
                        <img
                                src="<?= base_url($comment['profile_picture'] ?: 'uploads/profile_pictures/default.png') ?>"
                                class="comment-avatar"
                                alt="<?= esc($comment['username']) ?>"
                        >
                        <div class="comment-body">
                            <span class="comment-username"><?= esc($comment['username']) ?></span>
                            <p class="comment-text"><?= nl2br(esc($comment['content'])) ?></p>
                            <span class="comment-date"><?= date('M j · g:i a', strtotime($comment['created_at'])) ?></span>
                            <button class="btn-delete-comment" data-comment-id="<?= $comment['id'] ?>">×</button>
                        </div>
                    </div>
                <?php endforeach; ?>

                <form
                        method="post"
                        action="<?= route_to('posts.comments.store', $post['id']) ?>"
                        class="comment-form"
                        data-post-id="<?= $post['id'] ?>"
                >
                    <?= csrf_field() ?>
                    <img
                            src="<?= base_url(session('user_profile_picture') ?: 'uploads/profile_pictures/default.png') ?>"
                            class="comment-avatar"
                            alt="<?= lang('App.you') ?>"
                    >
                    <div class="comment-input-wrap">
                        <input
                                type="text"
                                name="content"
                                class="comment-input"
                                placeholder="<?= lang('App.write_comment') ?>"
                                maxlength="500"
                                required
                        >
                        <button type="submit" class="btn-send"><?= lang('App.send') ?></button>
                    </div>
                </form>

            </div>
        </article>
    <?php endforeach; ?>
<?php endif; ?>

<?= $this->endSection() ?>

<?= $this->section('scripts') ?>
    <script src="<?= base_url('assets/js/ajax.js') ?>"></script>
<?= $this->endSection() ?>