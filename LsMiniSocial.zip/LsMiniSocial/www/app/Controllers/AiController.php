<?php

namespace App\Controllers;

use GuzzleHttp\Client;
use GuzzleHttp\Exception\GuzzleException;

class AiController extends BaseController
{
    public function improve()
    {
        $content = trim($this->request->getPost('content') ?? '');

        if ($content === '') {
            return $this->response->setStatusCode(422)->setJSON(['error' => 'Content is required.']);
        }

        $apiKey = env('GEMINI_API_KEY');
        if (!$apiKey) {
            return $this->response->setStatusCode(500)->setJSON(['error' => 'AI service not configured.']);
        }

        $url = 'https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent?key=' . $apiKey;

        $client = new Client([ 'timeout' => 15]);

        try {
            $res = $client->post($url, [
                'json' => [
                    'contents' => [[
                        'parts' => [[
                            'text' => 'Improve the following social media post. Return only the improved text, no explanation, no quotes, no preamble: ' . $content,
                        ]],
                    ]],
                ],
            ]);
        } catch (GuzzleException $e) {
            log_message('error', 'Gemini request failed: ' . $e->getMessage());
            return $this->response->setStatusCode(502)->setJSON(['error' => 'AI service unavailable.']);
        }

        $data     = json_decode($res->getBody()->getContents(), true);
        $improved = $data['candidates'][0]['content']['parts'][0]['text'] ?? null;

        if (!$improved) {
            return $this->response->setStatusCode(502)->setJSON(['error' => 'Unexpected AI response.']);
        }

        return $this->response->setJSON(['improved' => trim($improved)]);
    }
}
