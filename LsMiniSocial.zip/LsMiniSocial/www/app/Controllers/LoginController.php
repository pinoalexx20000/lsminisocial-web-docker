<?php

namespace App\Controllers;

use App\Models\UserModel;

class LoginController extends BaseController
{

    public function signIn()
    {
        return view('login');
    }

    public function signInPost()
    {
        $rules = [
            'email' => 'required|valid_email',
            'password' => 'required'
        ];

        $errors = [
            'email' => [
                'required' => 'Email is required.',
                'valid_email' => 'The email address is not valid.'

            ],
            'password' => [
                'required' => 'Password is required.'
            ]
        ];

        if (!$this->validate($rules, $errors)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }

        return $this->authenticate();
    }

    private function authenticate()
    {
        $userModel = new UserModel();

        $email = $this->request->getPost('email');
        $password = $this->request->getPost('password');

        $user = $userModel->where('email', $email)->first();

        if (!$user || !password_verify($password, $user['password'])) {
            return redirect()->back()->withInput()->with('errors', [
                'password' => 'Your email and/or password are incorrect.'
            ]);
        }
        session()->set([
            'user_id' => $user['id'],
            'user_email' => $user['email'],
            'user_name' => $user['username'],
            'user_profile_picture' => $user['profile_pic'],
            'isLoggedIn' => true
        ]);

        return redirect()->route('home');
    }
    public function logout()
    {

        session()->destroy();

        return redirect()->route('login');
    }
}