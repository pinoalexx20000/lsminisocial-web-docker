<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Models\PostModel;

class ProfileController extends BaseController
{
    public function index()
    {
        $userModel = new UserModel();
        $postModel = new PostModel();

        $userId = session()->get('user_id');

        $user = $userModel->find($userId);

        if (!$user) {
            session()->destroy();
            return redirect()->route('login')->with('error', 'Please sign in to access this page.');
        }

        $posts = $postModel
            ->where('user_id', $userId)
            ->orderBy('created_at', 'DESC')
            ->findAll();

        return view('profile', [
            'user'  => $user,
            'posts' => $posts
        ]);
    }

    public function update()
    {
        $userModel = new UserModel();
        $userId = session()->get('user_id');
        $user = $userModel->find($userId);

        if (!$user) {
            session()->destroy();
            return redirect()->route('login')->with('error', 'Please sign in to access this page.');
        }

        $rules = [
            'username' => 'required|max_length[50]',
        ];

        $password = trim((string) $this->request->getPost('password'));

        if ($password !== '') {
            $rules['password'] = 'min_length[7]|regex_match[/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/]';
        }

        if (!$this->validate($rules)) {
            return redirect()->route('profile')->withInput()->with('errors', $this->validator->getErrors());
        }

        $data = [
            'username' => trim((string) $this->request->getPost('username')),
        ];

        if ($password !== '') {
            $data['password'] = password_hash($password, PASSWORD_DEFAULT);
        }

        $image = $this->request->getFile('profile_picture');

        if ($image && $image->isValid() && !$image->hasMoved()) {
            $newName = $image->getRandomName();
            $image->move(FCPATH . 'uploads/profile_pictures/', $newName);
            $data['profile_pic'] = 'uploads/profile_pictures/' . $newName;
        }

        $userModel->update($userId, $data);

        $updatedUser = $userModel->find($userId);

        session()->set([
            'user_name'            => $updatedUser['username'],
            'user_email'           => $updatedUser['email'],
            'user_profile_picture' => $updatedUser['profile_pic'] ?? null,
        ]);

        return redirect()->to('/profile')->with('success', 'Profile updated successfully');
    }

    public function deleteAccount()
    {
        $userModel = new UserModel();
        $userId = session()->get('user_id');

        $user = $userModel->find($userId);

        if (!$user) {
            session()->destroy();
            return redirect()->route('landing')->with('error', 'Account not found.');
        }

        $userModel->delete($userId);

        session()->destroy();

        return redirect()->to('/')->with('success', 'Account deleted successfully');
    }
}