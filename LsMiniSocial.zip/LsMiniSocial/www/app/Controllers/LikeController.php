<?php

namespace App\Controllers;

use App\Models\LikeModel;

class LikeController extends BaseController
{
    public function like(int $postId)
    {
        $userId    = session()->get('user_id');
        $likeModel = new LikeModel();

        if (!$likeModel->where(['post_id' => $postId, 'user_id' => $userId])->first()) {
            $likeModel->insert(['post_id' => $postId, 'user_id' => $userId]);
        }

        $count = $likeModel->where('post_id', $postId)->countAllResults();
        return $this->response->setJSON(['liked' => true, 'count' => $count]);
    }

    public function unlike(int $postId)
    {
        $userId    = session()->get('user_id');
        $likeModel = new LikeModel();

        $existing = $likeModel->where(['post_id' => $postId, 'user_id' => $userId])->first();
        if ($existing) {
            $likeModel->delete($existing['id']);
        }

        $count = $likeModel->where('post_id', $postId)->countAllResults();
        return $this->response->setJSON(['liked' => false, 'count' => $count]);
    }
}