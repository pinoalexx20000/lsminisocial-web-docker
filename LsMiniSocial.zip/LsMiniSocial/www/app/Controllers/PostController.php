<?php

namespace App\Controllers;

use App\Models\PostModel;

class PostController extends BaseController
{
    public function index()
    {
        $postModel = new PostModel();
        return $this->response->setJSON($postModel->findAll());
    }

    public function show($id)
    {
        $postModel = new PostModel();
        $post      = $postModel->find($id);

        if (!$post) {
            return $this->response->setStatusCode(404)->setJSON(['message' => 'Post not found']);
        }

        return $this->response->setJSON($post);
    }

    public function create()
    {
        return view('post/create');
    }

    public function store()
    {
        if (!$this->validate(['content' => 'required|max_length[1000]'])) {
            return redirect()->route('home')->with('errors', $this->validator->getErrors());
        }

        $image     = $this->request->getFile('image');
        $imagePath = null;

        if ($image && $image->isValid() && !$image->hasMoved()) {
            $newName = $image->getRandomName();
            $image->move(FCPATH . 'uploads/posts/', $newName);
            $imagePath = 'uploads/posts/' . $newName;
        }

        $postModel = new PostModel();
        $postModel->insert([
            'user_id' => session()->get('user_id'),
            'content' => $this->request->getPost('content'),
            'image'   => $imagePath,
        ]);

        return redirect()->route('home');
    }

    public function edit($id)
    {
        $postModel = new PostModel();
        $post      = $postModel->find($id);

        if (!$post) {
            return redirect()->route('home')->with('error', 'Post not found');
        }

        if ($post['user_id'] != session()->get('user_id')) {
            return redirect()->route('home')->with('error', 'You cannot edit this post');
        }

        return view('post/edit', ['post' => $post]);
    }

    public function update($id)
    {
        $postModel = new PostModel();
        $post      = $postModel->find($id);

        if (!$post) {
            return $this->response->setStatusCode(404)->setJSON(['message' => 'Post not found']);
        }

        if ($post['user_id'] != session()->get('user_id')) {
            return $this->response->setStatusCode(403)->setJSON(['message' => 'You cannot update this post']);
        }

        $content = trim((string) $this->request->getVar('content'));

        if ($content === '') {
            return $this->response->setStatusCode(422)->setJSON(['message' => 'Content must not be empty']);
        }

        $data  = ['content' => $content];
        $image = $this->request->getFile('image');

        if ($image && $image->isValid() && !$image->hasMoved()) {
            $newName = $image->getRandomName();
            $image->move(FCPATH . 'uploads/posts/', $newName);
            $data['image'] = 'uploads/posts/' . $newName;
        }

        $postModel->update($id, $data);

        return $this->response->setJSON(['message' => 'Post updated successfully']);
    }

    public function delete($id)
    {
        $postModel = new PostModel();
        $post      = $postModel->find($id);

        if (!$post) {
            return $this->response->setStatusCode(404)->setJSON(['error' => 'Post not found']);
        }

        if ($post['user_id'] != session()->get('user_id')) {
            return $this->response->setStatusCode(403)->setJSON(['error' => 'Forbidden']);
        }

        $postModel->delete($id);

        return $this->response->setJSON(['message' => 'Post deleted']);
    }
}