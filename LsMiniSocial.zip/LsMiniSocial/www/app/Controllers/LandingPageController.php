<?php

namespace App\Controllers;

class LandingPageController extends BaseController
{
    public function index()
    {
        if (session()->get('isLoggedIn')) {
            return redirect()->route('home');
        }

        return view('landing-page');
    }
}
