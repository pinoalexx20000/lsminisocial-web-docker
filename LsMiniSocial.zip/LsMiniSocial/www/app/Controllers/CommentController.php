<?php

namespace App\Controllers;

use App\Models\CommentModel;

class CommentController extends BaseController
{
    public function getByPost(int $postId)
    {
        $commentModel = new CommentModel();
        return $this->response->setJSON($commentModel->getCommentsWithUser($postId));
    }

    public function store(int $postId)
    {
        if (!$this->validate(['content' => 'required|max_length[500]'])) {
            return $this->response->setStatusCode(422)->setJSON(['errors' => $this->validator->getErrors()]);
        }

        $commentModel = new CommentModel();
        $id = $commentModel->insert([
            'post_id' => $postId,
            'user_id' => session()->get('user_id'),
            'content' => $this->request->getPost('content'),
        ]);

        return $this->response->setStatusCode(201)->setJSON($commentModel->getCommentWithUser((int) $id));
    }

    public function destroy(int $id)
    {
        $commentModel = new CommentModel();
        $comment      = $commentModel->find($id);

        if (!$comment) {
            return $this->response->setStatusCode(404)->setJSON(['error' => 'Comment not found']);
        }

        if ($comment['user_id'] != session()->get('user_id')) {
            return $this->response->setStatusCode(403)->setJSON(['error' => 'Forbidden']);
        }

        $commentModel->delete($id);
        return $this->response->setJSON(['message' => 'Deleted']);
    }
}