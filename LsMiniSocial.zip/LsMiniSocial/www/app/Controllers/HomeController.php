<?php

namespace App\Controllers;

use App\Models\PostModel;

class HomeController extends BaseController
{
    public function index()
    {
        $postModel = new PostModel();
        $posts     = $postModel->getPostsWithDetails(session()->get('user_id'));

        return view('home', ['posts' => $posts]);
    }
}
