<?php

namespace App\Controllers;

use App\Models\UserModel;
use App\Services\FileUploaderInterface;
use App\Services\UploadFiles;

class RegisterController extends BaseController
{

    public function signUp()
    {
        return view('register');
    }

    public function signUpPost()
    {
        $rules = [
            'email'            => 'required|valid_email|salle_email|is_unique[users.email]',
            'password'         => 'required|min_length[8]|regex_match[/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d).+$/]',
            'password_repeat'  => 'required|matches[password]',
            'profile_picture'  => 'if_exist|uploaded[profile_picture]|is_image[profile_picture]|max_size[profile_picture,2048]',
        ];

        $errors = [
            'email' => [
                'required'    => 'Email is required.',
                'valid_email' => 'The email address is not valid.',
                'salle_email' => 'Only emails from the domain @students.salle.url.edu, @ext.salle.url.edu or @salle.url.edu are accepted.',
                'is_unique'   => 'The email address is already registered.',
            ],
            'password' => [
                'required'    => 'Password is required.',
                'min_length'  => 'The password must contain at least 8 characters.',
                'regex_match' => 'The password must contain both upper and lower case letters and numbers.',
            ],
            'password_repeat' => [
                'required' => 'Repeat password is required.',
                'matches'  => 'Passwords do not match.',
            ],
            'profile_picture' => [
                'is_image' => 'The profile picture must be a valid image.',
                'max_size' => 'The profile picture must not exceed 2 MB.',
            ],
        ];

        if (!$this->validate($rules, $errors)) {
            return redirect()->back()->withInput()->with('errors', $this->validator->getErrors());
        }
        return $this->store();
    }

    private function store()
    {
        $userModel = new UserModel();

        $email    = $this->request->getPost('email');
        $username = $this->request->getPost('username');
        if (empty(trim($username))) {
            $username = strstr($email, '@', true);
        }



        $uploadService = new UploadFiles();
        $profilePicturePath = $uploadService->upload($this->request->getFile('profile_picture'));

        $data = [
            'email'           => $email,
            'username'        => $username,
            'password'        => password_hash($this->request->getPost('password'), PASSWORD_DEFAULT),
            'profile_picture' => $profilePicturePath,
        ];

        if ($userModel->insert($data)) {
            return redirect()->route('login');
        }
        return redirect()->back()->withInput()->with('errors', $userModel->errors());
    }
}