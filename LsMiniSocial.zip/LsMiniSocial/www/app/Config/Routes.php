<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */

$routes->get('/', 'LandingPageController::index', ['as' => 'landing']);

$routes->get('/sign-up', 'RegisterController::signUp', ['as' => 'register']);
$routes->post('/sign-up', 'RegisterController::signUpPost', ['as' => 'register.store']);

$routes->get('/sign-in', 'LoginController::signIn', ['as' => 'login']);
$routes->post('/sign-in', 'LoginController::signInPost', ['as' => 'login.store']);

$routes->get('/logout', 'LoginController::logout', ['as' => 'logout']);
$routes->get('/home', 'HomeController::index', ['as' => 'home']);

$routes->group('/post', static function ($routes) {
    $routes->get('create', 'PostController::create', ['as' => 'post.create']);
    $routes->get('edit/(:num)', 'PostController::edit/$1', ['as' => 'post.edit']);
});

$routes->group('/posts', static function ($routes) {
    $routes->get('', 'PostController::index', ['as' => 'posts.index']);
    $routes->post('', 'PostController::store', ['as' => 'posts.store']);
    $routes->get('(:num)', 'PostController::show/$1', ['as' => 'posts.show']);
    $routes->put('(:num)', 'PostController::update/$1', ['as' => 'posts.update']);
    $routes->post('(:num)', 'PostController::update/$1');
    $routes->delete('(:num)', 'PostController::delete/$1', ['as' => 'posts.delete']);

    $routes->post('(:num)/like', 'LikeController::like/$1', ['as' => 'posts.like']);
    $routes->delete('(:num)/like', 'LikeController::unlike/$1', ['as' => 'posts.unlike']);
    $routes->get('(:num)/comments', 'CommentController::getByPost/$1', ['as' => 'posts.comments']);
    $routes->post('(:num)/comments', 'CommentController::store/$1', ['as' => 'posts.comments.store']);
});

$routes->delete('/comments/(:num)', 'CommentController::destroy/$1', ['as' => 'comments.destroy']);

$routes->group('/profile', static function ($routes) {
    $routes->get('', 'ProfileController::index', ['as' => 'profile']);
    $routes->post('', 'ProfileController::update', ['as' => 'profile.update']);
    $routes->post('delete', 'ProfileController::deleteAccount', ['as' => 'profile.delete']);
});

$routes->group('/ai', static function ($routes) {
    $routes->post('improve', 'AiController::improve', ['as' => 'ai.improve']);
});
