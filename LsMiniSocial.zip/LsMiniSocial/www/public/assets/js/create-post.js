(function () {
    const fileInput = document.getElementById('post-image-input');
    if (fileInput) {
        fileInput.addEventListener('change', () => {
            document.getElementById('file-name-display').textContent =
                fileInput.files[0] ? fileInput.files[0].name : '';
        });
    }

    const btnImprove    = document.getElementById('btn-ai-improve');
    const textarea      = document.getElementById('post-content');
    const suggestionBox = document.getElementById('ai-suggestion');
    const suggestionTxt = document.getElementById('ai-suggestion-text');
    const btnAccept     = document.getElementById('btn-ai-accept');
    const btnReject     = document.getElementById('btn-ai-reject');

    if (!btnImprove) return;

    const improveUrl = btnImprove.dataset.improveUrl;
    let csrfValue    = document.querySelector('meta[name="csrf-token-value"]').content;

    function refreshCsrf() {
        const match = document.cookie.match(/(^|;\s*)csrf_cookie_name=([^;]+)/);
        if (match) csrfValue = decodeURIComponent(match[2]);
    }

    btnImprove.addEventListener('click', async () => {
        const content = textarea.value.trim();
        if (!content) return;

        btnImprove.disabled    = true;
        btnImprove.textContent = 'Improving…';

        try {
            const res = await fetch(improveUrl, {
                method: 'POST',
                headers: {
                    'X-Requested-With': 'XMLHttpRequest',
                    'X-CSRF-TOKEN': csrfValue,
                    'Content-Type': 'application/x-www-form-urlencoded',
                },
                body: new URLSearchParams({ content }),
            });
            refreshCsrf();
            const data = await res.json();

            if (!res.ok || data.error) {
                alert(data.error || 'AI improvement failed.');
                return;
            }

            suggestionTxt.textContent = data.improved;
            suggestionBox.style.display = 'block';
        } catch (e) {
            alert('Could not reach the AI service.');
        } finally {
            btnImprove.disabled  = false;
            btnImprove.innerHTML = `<svg width="15" height="15" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round" style="vertical-align:middle;margin-right:4px"><path d="M12 2L15.09 8.26L22 9.27L17 14.14L18.18 21.02L12 17.77L5.82 21.02L7 14.14L2 9.27L8.91 8.26L12 2Z"/></svg>Improve with AI`;
        }
    });

    btnAccept.addEventListener('click', () => {
        textarea.value = suggestionTxt.textContent;
        suggestionBox.style.display = 'none';
    });

    btnReject.addEventListener('click', () => {
        suggestionBox.style.display = 'none';
    });
})();
