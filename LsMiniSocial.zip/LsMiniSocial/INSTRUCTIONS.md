# INSTRUCTIONS — LsMiniSocial

## Requisitos previos

Solo necesitas tener instalado **Docker Desktop** y **Git**. No hace falta PHP ni MySQL en tu máquina, todo corre dentro de Docker.

---

## Instalación y puesta en marcha

### 1. Clonar el repositorio

```bash
git clone <repo-url>
cd LsMiniSocial
```

### 2. Configurar los .env

Hay dos archivos de configuración:

**`.env` (raíz del proyecto)** — controla los puertos de Docker. Lo importante es ajustar la arquitectura según tu máquina:

```
ARCH=linux/arm64   # Apple Silicon
ARCH=linux/amd64   # Intel / Windows
```

Los puertos por defecto son: app en `9080`, phpMyAdmin en `9081`, MySQL en `9306`.

**`www/.env`** — configuración de CodeIgniter. La base de datos ya viene configurada para conectar con el contenedor Docker. Lo único que tienes que añadir manualmente es la API key de Gemini (ver sección de IA más abajo):

```
GEMINI_API_KEY = tu_clave_aqui
```

### 3. Levantar los contenedores

```bash
docker compose up -d
```

La primera vez tarda un poco porque descarga las imágenes. Puedes comprobar que todo está corriendo con `docker compose ps` (deberían aparecer 4 servicios: app, mysql, nginx, phpmyadmin).

### 4. Ejecutar las migraciones

```bash
docker compose exec app php spark migrate
```

Esto crea las tablas `users`, `posts`, `likes` y `comments`.

### 5. Abrir la aplicación

- App: [http://localhost:9080](http://localhost:9080)
- phpMyAdmin: [http://localhost:9081](http://localhost:9081)

---

## Integración con IA (Google Gemini)

La funcionalidad de IA permite mejorar el texto de un post antes de publicarlo. Usa la API de **Gemini 2.5 Flash** de Google.

### Obtener la API key (gratis)

1. Entra en [https://aistudio.google.com/app/apikey](https://aistudio.google.com/app/apikey) con una cuenta de Google.
2. Crea una nueva API key y cópiala.
3. Pégala en `www/.env`:
   ```
   GEMINI_API_KEY = AIza...tu_clave
   ```
4. Reinicia el contenedor para que coja el cambio:
   ```bash
   docker compose restart app
   ```

### Cómo funciona

El botón "Improve with AI" aparece en los formularios de crear y editar posts. Al pulsarlo:

1. JavaScript hace un `fetch` a `POST /ai/improve` enviando el texto del textarea.
2. `AiController` recibe el texto, lo envía a la API de Gemini mediante Guzzle con el prompt: *"Improve the following social media post. Return only the improved text, no explanation, no quotes, no preamble: …"*
3. La respuesta se muestra en un cuadro debajo del textarea.
4. El usuario puede pulsar **Accept** para reemplazar su texto con la sugerencia, o **Discard** para ignorarla.

He decidido que la llamada sea síncrona (sin cola) porque el timeout de 15 segundos de Guzzle es suficiente para este contexto y simplifica bastante la implementación. Elegí Gemini 2.5 Flash por su capa gratuita generosa y la baja latencia en textos cortos.

Si la clave no está configurada o la API no responde, el controlador devuelve un error JSON con el código HTTP correspondiente (500 o 502) sin romper la página.

---

## Uso de la aplicación

### Registro

Solo se aceptan emails de La Salle (`@salle.url.edu`, `@students.salle.url.edu`, `@ext.salle.url.edu`). La validación está implementada como una regla personalizada de CodeIgniter en `App\Validation\CustomRules::salle_email`.

La contraseña debe tener mínimo 8 caracteres, con mayúsculas, minúsculas y números. La foto de perfil es opcional (máx. 2 MB).

### Posts

Desde el feed o desde "New Post" puedes crear posts de hasta 1000 caracteres con imagen opcional. Solo puedes editar y borrar tus propios posts. En la página de crear/editar hay el botón de mejora con IA.

### Likes y comentarios

El like se hace sin recargar la página (AJAX). Los comentarios también se envían y eliminan sin recargar. Solo puedes borrar tus propios comentarios.

### Perfil

Desde la sección Profile puedes cambiar el nombre de usuario, la contraseña (si lo dejas vacío no cambia) y la foto de perfil. También puedes borrar la cuenta desde ahí.

---

## Decisiones de implementación

**Validación de email por dominio** — En vez de hardcodear la lógica en el controlador, la metí en una regla personalizada de CI4 (`CustomRules::salle_email`). Así se puede reutilizar en otros formularios si hiciera falta y los mensajes de error siguen el mismo sistema que el resto de validaciones.

**AJAX para likes, comentarios y borrado** — Usar `fetch` en lugar de formularios tradicionales evita recargar el feed entero cada vez que el usuario hace una acción. El token CSRF se lee de las metas del HTML y se refresca desde la cookie tras cada petición.

**Subida de archivos en `public/uploads/`** — Las imágenes se guardan directamente en esa ruta para que Nginx las sirva como estáticos sin pasar por PHP. En la base de datos se guarda solo la ruta relativa (`uploads/posts/nombre.jpg`) y en las vistas se usa `base_url()` para construir la URL completa.

**Auth filter** — Todas las rutas que requieren estar logado están protegidas por `AuthFilter`. Si la petición incluye la cabecera `X-Requested-With` (AJAX) devuelve un 401 en JSON; si es una petición normal redirige al login.

---

## Parar / resetear

```bash
# Parar sin borrar datos
docker compose stop

# Parar y eliminar contenedores (los datos de la BD se conservan)
docker compose down

# Reset completo incluyendo la base de datos
docker compose down -v
# Después volver a ejecutar las migraciones
```
