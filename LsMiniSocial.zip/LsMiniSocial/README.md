# LsMiniSocial

Mini red social para estudiantes de La Salle. Puedes publicar posts con imágenes, dar likes, comentar, editar tu perfil y usar IA para mejorar el texto de tus posts antes de publicarlos.

Solo se pueden registrar emails `@salle.url.edu`, `@students.salle.url.edu` y `@ext.salle.url.edu`.

---

## Stack

- CodeIgniter 4 + PHP 8
- MySQL 8.4
- Nginx
- Docker / Docker Compose
- Guzzle (para llamadas a la API de Gemini)
- phpMyAdmin

---

## Screenshots

### Landing page
![Landing page](docs/screenshots/landing1.png)
![Landing page](docs/screenshots/landing2.png)

### Feed
![Feed](docs/screenshots/feed.png)

### Crear post con mejora por IA
![Create post](docs/screenshots/create-post-ai.png)

### Perfil
![Profile](docs/screenshots/profile.png)

### Registro
![Register](docs/screenshots/register.png)

---

## Arrancar el proyecto

Ver [INSTRUCTIONS.md](INSTRUCTIONS.md) para la guía completa con la configuración de la API key de IA.

```bash
git clone <repo-url>
cd LsMiniSocial

# Añadir la API key de Gemini en www/.env
# GEMINI_API_KEY = tu_clave_aqui

docker compose up -d
docker compose exec app php spark migrate

# http://localhost:9080
```

---

## Estructura

```
LsMiniSocial/
├── .env                        # puertos Docker
├── docker-compose.yaml
├── www/
│   ├── .env                    # config CodeIgniter + BD + AI
│   ├── app/
│   │   ├── Controllers/
│   │   │   ├── AiController.php
│   │   │   ├── PostController.php
│   │   │   ├── LikeController.php
│   │   │   ├── CommentController.php
│   │   │   ├── ProfileController.php
│   │   │   ├── RegisterController.php
│   │   │   └── LoginController.php
│   │   ├── Models/
│   │   ├── Views/
│   │   ├── Filters/AuthFilter.php
│   │   ├── Validation/CustomRules.php
│   │   └── Database/Migrations/
│   └── public/
│       ├── assets/js/
│       └── css/
└── docs/screenshots/
```

---

## Integración IA

Hay un botón "Improve with AI" en el formulario de crear/editar posts. Al pulsarlo se hace una llamada AJAX a `POST /ai/improve`, que desde el backend llama a la API de Gemini 2.5 Flash con el texto del post. La respuesta se muestra en un cuadro debajo del textarea y el usuario puede aceptarla o descartarla.

Para que funcione necesitas una API key de Google Gemini (ver INSTRUCTIONS.md).

---

## Rutas principales

```
GET  /                      landing
GET  /sign-up               registro
POST /sign-up
GET  /sign-in               login
POST /sign-in
GET  /home                  feed (requiere auth)
GET  /post/create
POST /posts                 crear post
GET  /post/edit/:id
POST /posts/:id             editar post
DELETE /posts/:id
POST /posts/:id/like
DELETE /posts/:id/like
POST /posts/:id/comments
DELETE /comments/:id
GET  /profile
POST /profile               actualizar perfil
POST /ai/improve            mejora con IA
```

---

## Variables de entorno relevantes

**`.env` raíz (Docker)**
```
NGINX_PORT=9080
PHPMYADMIN_PORT=9081
ARCH=linux/arm64   # cambiar a linux/amd64 en Intel/Windows
```

**`www/.env` (CodeIgniter)**
```
CI_ENVIRONMENT = development
app.baseURL = 'http://localhost:9080/'
GEMINI_API_KEY = <tu clave>
```
